package com.company;

public class Main {

    public static void main(String[] args) {

        Hamburger hamburger = new Hamburger("White","Chicken",1.5);
        hamburger.tomato.add();
        hamburger.cheese.add();
        hamburger.lettuce.add();
        hamburger.onion.add();
        hamburger.olives.add();
        hamburger.getCheck();
        System.out.println("______________________");
        hamburger.olives.remove();
        hamburger.getCheck();
    }


}
